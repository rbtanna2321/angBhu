         function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

    $(document).ready(function(){
        $(document).on("click","#FilterLink",function() {
            $(".filter-form").toggle();
      });
    });
    $(document).ready(function(){
        $(document).on("click","#polygon-icon",function() {
            $(".critical_alert_div").removeClass("display-none-css");
        });
        $(document).on("click","#remove-polygon-icon",function() {
            $(".critical_alert_div").addClass("display-none-css");
        });
        $(document).on("click","#sidebarToggle",function() {
            $("#accordionSidebar").toggleClass('toggled');;
          });
    });
   

