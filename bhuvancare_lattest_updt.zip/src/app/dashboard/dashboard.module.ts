import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { LayoutModule } from '../layout/layout.module';
import { SidebarModule } from '../layout/sidebar/sidebar.module';
import { ChartsModule } from 'ng2-charts';


import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule,
    ChartsModule
  ]
})

export class DashboardModule { }
