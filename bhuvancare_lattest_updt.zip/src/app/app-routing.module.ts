import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AuthGuard } from './shared';

const routes: Routes = [
    { path: '', loadChildren: './splash-screen/splash-screen.module#SplashScreenModule' },
    { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
    { path: 'sign-up', loadChildren: './signup/signup.module#SignupModule' },
    { path: 'otp', loadChildren: './signup/otp/otp.module#OtpModule' },
    { path: 'login', loadChildren: './login/login.module#LoginModule' },
    { path: 'forgot-password', loadChildren: './forgot-password/forgot-password.module#ForgotPasswordModule' },
    { path: 'trouble-in-sign-up', loadChildren: './signup/trouble-in-sign-up/trouble-in-sign-up.module#TroubleInSignUpModule' },
    { path: 'not-found', loadChildren: './not-found/not-found.module#NotFoundModule' },
    { path: 'your-client', loadChildren: './your-client/your-client.module#YourClientModule' },
    { path: 'vehicle-management', loadChildren: './vehicle-management/vehicle-management.module#VehicleManagementModule' },
    { path: 'driver-management', loadChildren: './driver-management/driver-management.module#DriverManagementModule' },
    { path: 'purchase-management', loadChildren: './purchase-management/purchase-management.module#PurchaseManagementModule' },
    { path: 'order-management', loadChildren: './order-management/order-management.module#OrderManagementModule' },
    { path: 'request-management', loadChildren: './request-management/request-management.module#RequestManagementModule' },
    
  //  { path: 'otp', loadChildren: './otp/otp.module#OtpModule' },
    { path: '**', redirectTo: 'not-found' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {}
