import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../router.animations';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../services/user.service';
import * as env from '../globals/env';
declare var $: any;

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    animations: [routerTransition()]
})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    submitted = false;
    logo = env.LOGO_PATH;
    error= "";
    constructor(
        public router: Router,
        public authService: AuthenticationService,
        private toaster: ToastrService,
        private fb: FormBuilder,
        private userService : UserService
    ) {}

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: getter function
        Use: This function is use for getting form controls
    */

    get f() {
      return this.loginForm.controls;
    }

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: initialize the app function
        Use: This function is use initialize the app
    */

    ngOnInit() {
        this.createForm();
    }

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: Validate the form field
        Use: This function is use for validate the function
    */

    createForm() {
        this.loginForm = this.fb.group({
            'email': ['', [ Validators.required, Validators.email ] ],
            'password': ['', [ Validators.minLength(5), Validators.maxLength(25) ] ]
        });
    }

    /*
        Developer: Ravi
        Date: 01-aug-2019
        title: open modal
        Use: This function is use for open success modal
    */

    showModal(){
        $("#resetPassEmail").modal('show');
    }

    showModal1(){
        $("#loginError").modal('show');
    }

    /*
        Developer: Ravi
        Date: 01-aug-2019
        title: close modal
        Use: This function is use for close success modal
    */

    closeModal(){
        $("#loginSuceess").modal('hide');
        this.router.navigate(['/dashboard']);
    }

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: submit the form
        Use: This function is use for submit the form and sumbit the validate data
    */

    onSubmit() {
        this.submitted = true;
        if (this.loginForm.invalid) {
            return;
        }else{
          const userObj ={
            url : "https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare/api/v1/ent/login",
            params : {
                email: this.loginForm.value.email,
                password: this.loginForm.value.password,
            }
          };
          this.userService.login(userObj).subscribe((data: any) => {

              if (data.status === "SUCCESS") {
                  //this.authService.storeUserData(data.token, data.user);
                  this.router.navigate(['/dashboard']);
              } else {
                this.error = data.error.message;
                $("#loginError").modal('show');
                //this.toaster.error(data.error);
              }
          });


           this.router.navigate(['/dashboard']);
        }
    }
}
