import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import 'rxjs/add/operator/map';
import * as env from '../globals/env';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  authToken: any;
  user: any;
  baseUrl: any = env.server_url();
  versionUrl : any = env.version_url();
  private superHeaders: Headers;

  constructor(private http: HttpClient) {}



  /**
   * Developed Name: Ravi K
   * Date: 30-07-2019
   * @desc Sign up enterprise
   *
   */
  signupEnterprise(user: any) {
    console.log(user);
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json; charset=utf-8');

    return this.http.post('http://localhost:8080/api/test', user, {headers});
  }

  otpVerify(user: any) {
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json; charset=utf-8');

    return this.http.post('http://localhost:8080/api/test', user, {headers});
  }

   /**
   * Developed Name: Ravi K
   * Date: 30-07-2019
   * @desc Sign up enterprise
   *
   */
  login(user: any) {
    console.log(user);
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json; charset=utf-8');

    return this.http.post('http://localhost:8080/api/test', user, {headers});
     //return this.http.get("https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare//api/v1/ent/forgotPassWord/9510076337" );
     //return this.http.post(	"http://dummy.restapiexample.com/api/v1/create",user, {headers : headers} );
  }


  addVehicle(user: any) {
    console.log(user);

    const headers = new HttpHeaders({
      'Content-Type': 'text/plain'
  });
    return this.http.post(this.baseUrl + this.versionUrl +  '/login', user, {headers});
     //return this.http.get("https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare//api/v1/ent/forgotPassWord/9510076337" );
     //return this.http.post(	"http://dummy.restapiexample.com/api/v1/create",user, {headers : headers} );
}

forgotPassword(user: any) {
  console.log(user);

  const headers = new HttpHeaders({
    'Content-Type': 'text/plain'
});
  return this.http.post(this.baseUrl + this.versionUrl +  '/forgot-password', user, {headers});
   //return this.http.get("https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare//api/v1/ent/forgotPassWord/9510076337" );
   //return this.http.post(	"http://dummy.restapiexample.com/api/v1/create",user, {headers : headers} );
}

    /**
     * Developed Name: Ravi K
     * Date: 27-03-2019
     * @desc Update user
     *
     * @return json
     */

    UpdateUser(user) {
        const headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.http.post(this.baseUrl + '/users/update', user, {headers: headers});
    }

    /**
     * Developed Name: Ravi K
     * Date: 28-03-2019
     * @desc Change Password
     *
     * @return json
     */
    changePassword(passwordObj: any) {
        const headers = new HttpHeaders();
        headers.append('Content-type', 'application/json');
        return this.http.post(this.baseUrl + '/users/change-password', passwordObj, {headers: headers});
    }

    /**
     * Developed Name: Ravi K
     * Date: 28-03-2019
     * @desc Change Password
     *
     * @return json
     */
    countryData() {
        const headers = new HttpHeaders();
        headers.append('Content-type', 'application/json');
        return this.http.get(this.baseUrl + '/country/all', {headers: headers});
    }

    /**
     * Developed Name: Ravi K
     * Date: 28-03-2019
     * @desc Change Password
     *
     * @return json
     */
    singleCountryData(id) {
        const headers = new HttpHeaders();
        headers.append('Content-type', 'application/json');
        return this.http.get(this.baseUrl + '/country/single/' + id, {headers: headers});
    }

  actionUser(data) {
    const headers = new HttpHeaders();
    return this.http.post(this.baseUrl + '/users/actionUser', data, {headers: headers});
  }
}
