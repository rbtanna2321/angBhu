import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import * as env from '../globals/env';

@Injectable({
  providedIn: 'root'
})
export class FeatureService {
  baseUrl: any = "";
  constructor(private http: HttpClient) { }

  createAuthorizationHeader(headers: HttpHeaders) {
    headers.append('Authorization', 'Basic ');
  }

  listFeature() {
    const headers = new HttpHeaders();
    headers.append('Content-type', 'application/json');
    return this.http.get(this.baseUrl + '/plan/GetAllFeatures');
  }

  /**
   * Developed Name: Meet Shah
   * Date: 19-04-2019
   * @desc Add Feature
   *
   * @return json
   */

  addFeature(feature) {
    const headers = new HttpHeaders();
    return this.http.post(this.baseUrl + '/plan/addfeature', feature, {headers: headers});
  }

  viewFeature(feature) {
    const headers = new HttpHeaders();
    return this.http.post(this.baseUrl + '/plan/viewFeature', feature, {headers: headers});
  }

  updateFeature(feature) {
    const headers = new HttpHeaders();
    return this.http.post(this.baseUrl + '/plan/updatefeature', feature, {headers: headers});
  }

  deleteFeature(feature) {
    const headers = new HttpHeaders();
    return this.http.post(this.baseUrl + '/plan/deletefeature', feature, {headers: headers});
  }
}
