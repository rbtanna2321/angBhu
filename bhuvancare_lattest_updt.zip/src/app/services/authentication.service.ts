import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import 'rxjs/add/operator/map';
import * as env from '../globals/env';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  authToken: any;
  user: any;
  baseUrl: any = env.server_url();

  constructor(private http: HttpClient) { }

  /**
  * Developed Name: Ravi Kadia
  * Date: 08-08-2018
  * @desc Check if user is logged in
  *
  * @return Boolean
  */
  loggedIn() {
      const token = localStorage.getItem('token');
      if (token !== null) {
          return true;
      } else {
          return false;
      }
  }

  checkaccess(access_data) {
    const headers = new HttpHeaders();
    headers.append('Content-type', 'application/json');
    return this.http.post(this.baseUrl + '/roles/check_access', access_data, { headers: headers });
  }

  getmodulename(moduleName) {
      const headers = new HttpHeaders();
      headers.append('Content-type', 'application/json');
      return this.http.post(this.baseUrl + '/roles/module_search', moduleName, {headers: headers});
  }

  logout() {
   localStorage.clear();
   return true;
  }

  /**
     * Developed Name: Ravi K
     * Date: 08-04-2019
     * @desc Login user
     *
     * @return json
     */

    loginUser(user) {
        const headers = new HttpHeaders();
        headers.append('Content-type', 'application/json');
        return this.http.post(this.baseUrl + '/users/login', user, {headers: headers});
    }

    /**
     * Developed Name: Ravi K
     * Date: 08-04-2019
     * @desc Login admin
     *
     * @return json
     */

    loginAdmin(user) {
        const headers = new HttpHeaders();
        headers.append('Content-type', 'application/json');
        return this.http.post(this.baseUrl + '/users/admin_login', user, {headers: headers});
    }
  /**
  * Developed Name: kadia ravi
  * Date: 6-08-2018
  * @desc Store login data in local storage
  *
  */
  storeUserData(token, user) {
      localStorage.setItem('token', token);
      // localStorage.setItem('care_management_user', JSON.stringify(user));
      this.authToken = token;
      this.user = user;
  }

  /**
    * Developed Name: Ravi K
    * Date: 25-03-2018
    * @desc Forgot Password
    *
    */
  forgotPassword(user) {
     const headers = new HttpHeaders();
     headers.append('Content-type', 'application/json');
     return this.http.post(this.baseUrl + '/users/forgot-password', user, {headers: headers});
  }

  /**
  * Developed Name: Ravi K
  * Date: 25-03-2018
  * @desc Reset Password
  *
  */
  resetPassword(user) {
      const headers = new HttpHeaders();
      headers.append('Content-type', 'application/json');
      return this.http.post(this.baseUrl + '/users/reset-password', user, {headers: headers});
  }
}
