import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddRequestRoutingModule } from './add-request-routing.module';
import { AddRequestComponent } from './add-request.component';
import { LayoutModule } from '../../layout/layout.module';
import { SidebarModule } from '../../layout/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { ArchwizardModule } from 'ng2-archwizard';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  declarations: [AddRequestComponent],
  imports: [
    CommonModule,
    AddRequestRoutingModule,
    LayoutModule,
    SidebarModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    ArchwizardModule,
    NgbModule
  ]
})
export class AddRequestModule { }
