import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutModule } from '../layout/layout.module';
import { SidebarModule } from '../layout/sidebar/sidebar.module';
import { ListViewModule } from '../layout/list-view/list-view.module';
import { RequestManagementRoutingModule } from './request-management-routing.module';
import { RequestManagementComponent } from './request-management.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { AddRequestModule } from './add-request/add-request.module';
import { ViewRequestModule } from './view-request/view-request.module';
@NgModule({
  declarations: [RequestManagementComponent],
  imports: [
    CommonModule,
    RequestManagementRoutingModule,
    LayoutModule,
    SidebarModule,
    TranslateModule,
    FormsModule,
    AddRequestModule,
    ViewRequestModule,
    ListViewModule
    
  ]
})
export class RequestManagementModule { }
