import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RequestManagementComponent } from './request-management.component';
import { AddRequestComponent } from './add-request/add-request.component';
import { ViewRequestComponent } from './view-request/view-request.component';

const routes: Routes = [
  {
      path: '',
      component: RequestManagementComponent
  },
  {
    path: 'add',
    component: AddRequestComponent
},
{
  path: 'view',
  component: ViewRequestComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RequestManagementRoutingModule { }
