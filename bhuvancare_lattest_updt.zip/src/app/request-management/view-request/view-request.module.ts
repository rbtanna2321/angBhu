import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewRequestRoutingModule } from './view-request-routing.module';
import { ViewRequestComponent } from './view-request.component';
import { LayoutModule } from '../../layout/layout.module';
import { SidebarModule } from '../../layout/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [ViewRequestComponent],
  imports: [
    CommonModule,
    ViewRequestRoutingModule,
    LayoutModule,
    SidebarModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class ViewRequestModule { }
