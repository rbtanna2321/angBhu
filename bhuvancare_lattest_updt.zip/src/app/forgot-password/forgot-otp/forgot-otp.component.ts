import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../../router.animations';
import { AuthenticationService } from '../../services/authentication.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { interval } from 'rxjs/observable/interval';
import { Observable, timer } from 'rxjs';
import { take, map } from 'rxjs/operators';
import * as env from '../../globals/env';

declare var $: any;

@Component({
  selector: 'app-forgot-otp',
  templateUrl: './forgot-otp.component.html',
  styleUrls: ['./forgot-otp.component.scss'],
  animations: [routerTransition()]
})
export class ForgotOtpComponent implements OnInit {
  otpForm : FormGroup;
  submitted = false;
  counter$: Observable<number>;
  count = env.OTP_SECONDS;
  logo = env.LOGO_PATH;
   
  constructor(
      public router: Router,
      public authService: AuthenticationService,
      private toaster: ToastrService,
      private fb: FormBuilder
    ) {
      this.counter$ = timer(0,1000).pipe(
       take(this.count),
       map(() => --this.count)
     );
    }

  ngOnInit() {
      this.createForm();
  }
  keytab(event){
    let nextInput = event.srcElement.nextElementSibling; // get the sibling element

    var target = event.target || event.srcElement;
    var id = target.id
    if(nextInput == null)  // check the maxLength from here
        return;
    else
        nextInput.focus();   // focus if not null
}

  get f() {
    return this.otpForm.controls;
  }

  createForm() {
      this.otpForm = this.fb.group({
        'otpDigit1': ['', [Validators.required ] ],
        'otpDigit2': ['', [Validators.required ] ],
        'otpDigit3': ['', [Validators.required ] ],
        'otpDigit4': ['', [Validators.required ] ],
        'otpDigit5': ['', [Validators.required ] ],
        'otpDigit6': ['', [Validators.required ] ]
      });
  }


  onSubmit() {
    this.submitted = true;
    if (this.otpForm.invalid) {
        return;
    }else{
        this.router.navigate(['/forgot-password/reset-password']);
    }
  }

}
