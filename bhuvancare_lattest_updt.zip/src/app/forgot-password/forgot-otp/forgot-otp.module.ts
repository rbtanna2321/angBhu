import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ForgotOtpComponent } from './forgot-otp.component';
import { ForgotOtpRoutingModule } from './forgot-otp-routing.module';

const routes: Routes = [
    {
        path: '',
        component: ForgotOtpComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class ForgotOtpModule { }
