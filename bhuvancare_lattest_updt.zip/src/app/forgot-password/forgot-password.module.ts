import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForgotPasswordComponent } from './forgot-password.component';
import { ForgotOtpComponent } from './forgot-otp/forgot-otp.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';


import { ForgotPasswordRoutingModule } from './forgot-password-routing.module';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [ForgotPasswordComponent,ForgotOtpComponent,ResetPasswordComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ForgotPasswordRoutingModule
  ]
})
export class ForgotPasswordModule { }
