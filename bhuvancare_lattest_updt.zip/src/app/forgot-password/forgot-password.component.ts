import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { routerTransition } from '../router.animations';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../services/user.service';
import * as env from '../globals/env';
declare var $: any;

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
  animations: [routerTransition()]
})
export class ForgotPasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  submitted = false;
  logo = env.LOGO_PATH;

  constructor(
      public router: Router,
      private fb: FormBuilder,
      private userService : UserService,
      private toaster: ToastrService,
    ) {}

  /*
      Developer: Ravi
      Date: 27-jul-2019
      title: getter function
      Use: This function is use for getting form controls
  */

  get f() {
    return this.forgotPasswordForm.controls;
  }

  /*
      Developer: Ravi
      Date: 25-jul-2019
      title: initialize the app function
      Use: This function is use initialize the app
  */

  ngOnInit() {
    this.createForm()
  }

  /*
      Developer: Ravi
      Date: 25-jul-2019
      title: Validate the form field
      Use: This function is use for validate the function
  */

  createForm() {
    this.forgotPasswordForm = this.fb.group({
        'emailId': ['', [ Validators.required, Validators.email ] ]
    });
  }

  /*
      Developer: Ravi
      Date: 01-aug-2019
      title: open modal
      Use: This function is use for open success modal
  */

  showModal(){
      $("#forgotPasswordModal").modal('show');
  }

  /*
      Developer: Ravi
      Date: 01-aug-2019
      title: close modal
      Use: This function is use for close success modal
  */

  closeModal(){
      $("#forgotPasswordModal").modal('hide');
      this.router.navigate(['/forgot-password/otp']);
  }

  /*
      Developer: Ravi
      Date: 25-jul-2019
      title: submit the form
      Use: This function is use for submit the form and sumbit the validate data
  */

  onSubmit() {
    this.submitted = true;
    if (this.forgotPasswordForm.invalid) {
        return;
    }else{
        this.showModal();
        const userObj = {
          vehicleNo: "9712304978",
          vehicleType: "123456",
          rc: "9712304978",
          puc: "123456",
          insurance: "9712304978"
      };
  
      this.userService.addVehicle(userObj).subscribe((data: any) => {
          console.log(data);
          if (data.success === true) {
              // this.authService.storeUserData(data.token, data.user);
              // this.router.navigate(['/dashboard']);
              // this.toaster.success(data.message);
          } else {
              this.toaster.error(data.message);
          }
      });
    }
  }

}
