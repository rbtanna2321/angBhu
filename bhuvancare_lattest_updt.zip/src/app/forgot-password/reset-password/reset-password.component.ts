import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../../router.animations';
import { AuthenticationService } from '../../services/authentication.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { interval } from 'rxjs/observable/interval';
import { Observable, timer } from 'rxjs';
import { take, map } from 'rxjs/operators';
import * as env from '../../globals/env';

declare var $: any;

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
  animations: [routerTransition()]
})


export class ResetPasswordComponent implements OnInit {
  resetForm : FormGroup;
  submitted = false;
  counter$: Observable<number>;
  count = env.OTP_SECONDS;
  logo = env.LOGO_PATH;

  constructor(
      public router: Router,
      public authService: AuthenticationService,
      private toaster: ToastrService,
      private fb: FormBuilder
    ) {
      this.counter$ = timer(0,1000).pipe(
       take(this.count),
       map(() => --this.count)
     );
    }

  ngOnInit() {
      this.createForm();
  }

  get f() {
    console.log(this.resetForm.controls);
    return this.resetForm.controls;
  }

  createForm() {
      this.resetForm = this.fb.group({
        'password': ['', [Validators.required ] ],
        'confirmPassword': ['', [Validators.required ] ],
      });
  }


    /*
        Developer: Ravi
        Date: 01-aug-2019
        title: open modal
        Use: This function is use for open success modal
    */

    showModal(){
        $("#resetPassEmail").modal('show');
    }

    /*
        Developer: Ravi
        Date: 01-aug-2019
        title: close modal
        Use: This function is use for close success modal
    */

    closeModal(){
        $("#resetPassEmail").modal('hide');
        this.router.navigate(['/login']);
    }

  onSubmit() {
    this.submitted = true;
    if (this.resetForm.invalid) {
        return;
    }else{
        this.showModal();
        //this.router.navigate(['/forgot-password/reset-password']);
    }
  }

}
