import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewOrderRoutingModule } from './view-order-routing.module';
import { ViewOrderComponent } from './view-order.component';
import { LayoutModule } from '../../layout/layout.module';
import { SidebarModule } from '../../layout/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [ViewOrderComponent],
  imports: [
    CommonModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule,
    ViewOrderRoutingModule
  ]
})
export class ViewOrderModule { }
