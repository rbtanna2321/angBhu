import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { OrderManagementComponent } from './order-management.component';
import { AddOrderComponent } from './add-order/add-order.component';
import { ViewOrderComponent } from './view-order/view-order.component';


const routes: Routes = [
  {
      path: '',
      component: OrderManagementComponent
  },
  {
      path: 'add',
      component: AddOrderComponent
  },
  {
      path: 'view',
      component: ViewOrderComponent
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class OrderManagementRoutingModule { }
