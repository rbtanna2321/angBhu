import { Component, OnInit , ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { routerTransition } from '../../router.animations';
import { UserService } from '../../services/user.service';
import * as env from '../../globals/env';
import * as validate from '../../globals/validate';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import {MovingDirection, WizardComponent} from 'ng2-archwizard';
import { NgbModal, NgbTimepicker} from '@ng-bootstrap/ng-bootstrap';
declare var $: any;
@Component({
  selector: 'app-add-order',
  templateUrl: './add-order.component.html',
  animations: [routerTransition()]
})
export class AddOrderComponent implements OnInit {
  @ViewChild(WizardComponent)
  public wizard: WizardComponent;
  // this is for first step
  orderForm1: FormGroup;
  form1submit = false;
  form1Valid = true;
   // this is for two step
   orderForm2: FormGroup;
   form2submit = false;
   form2Valid = true;
   // this is for two step
   orderForm3: FormGroup;
   form3submit = false;
   form3Valid = true;
  constructor(
    public router: Router,
    private fb: FormBuilder,
    private toaster: ToastrService,
    private userService : UserService
  ) { }

 /*
        Developer: Ravi
        Date: 08-aug-2019
        title: getter function
        Use: This function is use for getting form controls
    */

   get f1() {
   
    return this.orderForm1.controls;
  }
  get f2() {
    console.log(this.orderForm2.controls);
    return this.orderForm2.controls;
  }
  get f3() {
    return this.orderForm3.controls;
  }
  /*
        Developer: Ravi
        Date: 08-Aug-2019
        title: initialize the app function
        Use: This function is use initialize the app
    */

   ngOnInit() {
    this.createForm()
  }

   /*
        Developer: Ravi
        Date: 08-aug-2019
        title: open modal
        Use: This function is use for open success modal
    */

   showModal(){
    $("#successModal").modal('show');
}

/*
    Developer: Ravi
    Date: 08-aug-2019
    title: close modal
    Use: This function is use for close success modal
*/

closeModal(){
    $("#successModal").modal('hide');
    this.router.navigate(['/order-management']);
}

 /*
        Developer: Ravi
        Date: 08-aug-2019
        title: Validate the form field
        Use: This function is use for validate the function
    */

   createForm() {
    this.orderForm1 = this.fb.group({
      'orderName': ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.firtsNameMin), Validators.maxLength(validate.addOrderRules.firtsNameMax)]],
      'contactNumber' : ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.mobileMin), Validators.maxLength(validate.addOrderRules.mobileMax)]],
      'orderType' : ['',[ Validators.required]],
      'numberOfTrip' : ['',[ Validators.required]],
      'startDate' : ['',[ Validators.required]],
      'endDate' : ['',[ Validators.required]],
      'email' : ['',[ Validators.required]],
    });
    this.orderForm2 = this.fb.group({
      'address1' : ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.addressMin), Validators.maxLength(validate.addOrderRules.addressMax)]],
      'address2' : ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.addressMin), Validators.maxLength(validate.addOrderRules.addressMax)]],
      'state' : ['',[ Validators.required]],
      'city' : ['',[ Validators.required]],
      'pincode' : ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.pinCodeMin), Validators.maxLength(validate.addOrderRules.pinCodeMax)]]
  });
  this.orderForm3 = this.fb.group({
    'address1' : ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.addressMin), Validators.maxLength(validate.addOrderRules.addressMax)]],
    'address2' : ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.addressMin), Validators.maxLength(validate.addOrderRules.addressMax)]],
    'state' : ['',[ Validators.required]],
    'city' : ['',[ Validators.required]],
    'pincode' : ['',[ Validators.required,  Validators.minLength(validate.addOrderRules.pinCodeMin), Validators.maxLength(validate.addOrderRules.pinCodeMax)]]
});
}

// onFileChange(event) {
//   var Target = event.target;
//   var idAttr = Target.attributes.id;
//   console.log(idAttr);
//   var value = idAttr.nodeValue;
//     if(value == "attchRc"){
//       this.attchRc = event.target.files[0].name;
//     } 
   
    

// }

/*
    Developer: Ravi
    Date: 08-aug-2019
    title: submit the form
    Use: This function is use for submit the form and sumbit the validate data
*/

   // this is for first step submit validation
   onSubmit1(){
    this.form1submit = true;
    if (this.orderForm1.invalid) {
        return;
    }else{
      this.wizard.navigation.goToStep(1);
      this.form1Valid = true;
    }
  }
  // this is for Second step submit validation
  onSubmit2(){
    this.form2submit = true;
    if (this.orderForm2.invalid) {
        return;
    }else{
      this.wizard.navigation.goToStep(2);
      this.form2Valid = true;
    }
  }
  // this is for first step2 submit validation
  onSubmit3(){
    this.form3submit = true;
    if (this.orderForm3.invalid) {
        return;
    }else{
      this.showModal();
      const userObj = {
        vehicleNo: "9712304978",
        vehicleType: "123456",
        rc: "9712304978",
        puc: "123456",
        insurance: "9712304978"
    };

    this.userService.addVehicle(userObj).subscribe((data: any) => {
        console.log(data);
        if (data.success === true) {
            // this.authService.storeUserData(data.token, data.user);
            // this.router.navigate(['/dashboard']);
            // this.toaster.success(data.message);
        } else {
            this.toaster.error(data.message);
        }
    });

      this.wizard.navigation(['/order-management']);
    }
  }
}
