import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderManagementComponent } from './order-management.component';
import { OrderManagementRoutingModule } from './order-management-routing.module';
import { LayoutModule } from '../layout/layout.module';
import { SidebarModule } from '../layout/sidebar/sidebar.module';
import { ListViewModule } from '../layout/list-view/list-view.module';

import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { AddOrderModule } from './add-order/add-order.module';
import { ViewOrderModule } from './view-order/view-order.module';
@NgModule({
  declarations: [OrderManagementComponent],
  imports: [
    CommonModule,
    OrderManagementRoutingModule,
    LayoutModule,
    SidebarModule,
    TranslateModule,
    FormsModule,
    AddOrderModule,
    ViewOrderModule,
    ListViewModule
  ]
})
export class OrderManagementModule { }
