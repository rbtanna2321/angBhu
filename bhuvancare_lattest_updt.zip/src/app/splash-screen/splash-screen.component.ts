import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../router.animations';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-splash-screen',
  templateUrl: './splash-screen.component.html',
  styleUrls: ['./splash-screen.component.scss']
})
export class SplashScreenComponent implements OnInit {
  showElement = false;

  constructor(private router: Router) { }

  ngOnInit() {
    // window.addEventListener('load', async () => {
    //   let video = document.querySelector('video[muted][autoplay]');
    //   try {
    //     await video.play();
    //   } catch (err) {
    //     video.controls = true;
    //   }
    // });
    setTimeout(() => {
      this.showElement = true;
    }, 2000);

    setTimeout(() => {
        this.router.navigate(['/sign-up']);
    }, 90000);
  }
}
