'use strict';

/*
    Developer: Ravi
    Date: 25-jul-2019
    title: Validation rule for sign up form
    Use: This function is use for set global validation rules
*/


export const signupRules = {
      comapnyNameMax : 100,
      comapnyNameMin : 3,
      gstnoRegex : /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9]{1}Z[0-9]{1}?$/,
      gstNoMax : 3,
      gstNoMin : 10,
      natureOfBusinessMin : 15,
      numericRegex : /^[0-9]+$/,
      natureOfBusinessMax : 5,
      mobileMin : 10,
      mobileMax : 10,
      contactNoMax : 10,
      contactNoMin : 10,
      emailMax : 50,
      emailMin : 5,
      addressLine1Max : 500,
      addressLine1Min : 5,
      pinCodeMax : 6,
      pinCodeMin : 6
    };

/*
        Developer: Ravi
        Date: 8-aug-2019
        title: Validation rule for driver form
        Use: This function is use for set global validation rules fro driver form
*/

export const addDriverRules = {
      titleMax : 100,
      titleMin : 3,
      firtsNameMax : 100,
      firtsNameMin : 3,
      lastNameMax : 100,
      lastNameMin : 3,
      mobileMin : 10,
      mobileMax : 15,
      bloodMin : 2,
      bloodMax : 5,
      addressMin: 5,
      addressMax: 100,
      pinCodeMax : 6,
      pinCodeMin : 6,
      accNumberMin : 16,
      accNumberMax : 20,
      bankNameMin : 5,
      bankNameMax : 50,
      ifscCodeMin : 5,
      ifscCodeMax : 10,
      relationMin : 5,
      relationMax : 10,
    };

    /*
        Developer: Ravi
        Date: 8-aug-2019
        title: Validation rule for driver form
        Use: This function is use for set global validation rules fro driver form
*/

export const addVehicleRules = {
  titleMax : 100,
  titleMin : 3,
  firtsNameMax : 100,
  firtsNameMin : 3,
  lastNameMax : 100,
  lastNameMin : 3,
  mobileMin : 10,
  mobileMax : 15,
  bloodMin : 2,
  bloodMax : 5,
  addressMin: 5,
  addressMax: 100,
  pinCodeMax : 6,
  pinCodeMin : 6,
  regNumberMin : 5,
  regNumberMax : 20,
  bankNameMin : 5,
  bankNameMax : 50,
  ifscCodeMin : 5,
  ifscCodeMax : 10,
  relationMin : 5,
  relationMax : 10,
};

export const addOrderRules = {
  titleMax : 100,
  titleMin : 3,
  firtsNameMax : 100,
  firtsNameMin : 3,
  lastNameMax : 100,
  lastNameMin : 3,
  mobileMin : 10,
  mobileMax : 15,
  bloodMin : 2,
  bloodMax : 5,
  addressMin: 5,
  addressMax: 100,
  pinCodeMax : 6,
  pinCodeMin : 6,
  regNumberMin : 5,
  regNumberMax : 20,
  bankNameMin : 5,
  bankNameMax : 50,
  ifscCodeMin : 5,
  ifscCodeMax : 10,
  relationMin : 5,
  relationMax : 10,
};

export const addRequestRules = {
  titleMax : 100,
  titleMin : 3,
  firtsNameMax : 100,
  firtsNameMin : 3,
  lastNameMax : 100,
  lastNameMin : 3,
  mobileMin : 10,
  mobileMax : 15,
  bloodMin : 2,
  bloodMax : 5,
  addressMin: 5,
  addressMax: 100,
  pinCodeMax : 6,
  pinCodeMin : 6,
  regNumberMin : 5,
  regNumberMax : 20,
  bankNameMin : 5,
  bankNameMax : 50,
  ifscCodeMin : 5,
  ifscCodeMax : 10,
  relationMin : 5,
  relationMax : 10,
};
