'use strict';

// server config
export function server_url() {
        return 'https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare';
};

export function version_url() {
        return '/api/v1/ent/';
};
export const LOGO_PATH = 'assets/images/logo.png';
export const PROFILE_IMAGE_PATH = 'uploads/avatar';
export const CERTY_IMAGE_PATH = 'uploads/certificate';
export const DOCUMENT_PATH = 'uploads/documents';

// project config
export const PROJECT_NAME = 'Driver Bandhu';
export const PROJECT_LOGO_URL = 'assets/images/logo-light-text1.png';
export const PROJECT_LOGO_SMALL_URL = 'assets/images/logo-text.png';
export const ICON_ROOT = 'assets/images/';

export const OTP_SECONDS = 120;

// set static variables
export const STATIC_PROFILE_IMAGE = 'assets/images/defaultprofile.png';

export const validationRules = {
      comapnyNameMax : 100
};
