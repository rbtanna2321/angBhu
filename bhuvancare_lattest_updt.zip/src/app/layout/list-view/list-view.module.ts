import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ListViewRoutingModule } from './list-view-routing.module';
import { ListViewComponent } from './list-view.component';

const routes: Routes = [
  {
      path: '',
      component: ListViewComponent
  }
];

@NgModule({
  declarations: [ListViewComponent],
  imports: [
    CommonModule,
    ListViewRoutingModule,
    RouterModule.forChild(routes)
  ],
  exports : [
    ListViewComponent,
    RouterModule
  ],
})
export class ListViewModule { }
