import { Component, OnInit } from '@angular/core';
import * as env from '../../globals/env';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  logo = env.LOGO_PATH;
  iconRoot = env.ICON_ROOT;

  constructor() { }

  ngOnInit() {
  }

}
