import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SidebarComponent } from './sidebar.component';
import { SidebarRoutingModule } from './sidebar-routing.module';
import {ProgressBarModule} from "angular-progress-bar"
const routes: Routes = [
    {
        path: '',
        component: SidebarComponent
    }
];

@NgModule({
  declarations: [SidebarComponent],
  imports: [
    CommonModule,
    SidebarRoutingModule,
    ProgressBarModule,
    RouterModule.forChild(routes)
  ],
  exports : [
    SidebarComponent,
    RouterModule
  ],
})
export class SidebarModule { }
