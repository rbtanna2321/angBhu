import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { interval } from 'rxjs/observable/interval';
import { Observable, timer } from 'rxjs';
import { take, map } from 'rxjs/operators';
import {Location} from '@angular/common';



@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  constructor(private location: Location ) { }

  goBack() {
    this.location.back();
    console.log( 'goBack()...');
  }
  goForward() {
    this.location.forward();
    console.log( 'goForward()...');
  }

  ngOnInit() {
    // this.ngProgress.start();
    // this.http.get(this.baseUrl).subscribe(res){
    //     /** request completed */
    //     this.ngProgress.done();
    // }
  }
}
