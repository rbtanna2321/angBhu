import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-management',
  templateUrl: './vehicle-management.component.html',
  styleUrls: ['./vehicle-management.component.scss']
})
export class VehicleManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
