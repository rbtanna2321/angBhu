import { Component, OnInit , ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { routerTransition } from '../../router.animations';
import { UserService } from '../../services/user.service';
import * as env from '../../globals/env';
import * as validate from '../../globals/validate';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import {MovingDirection, WizardComponent} from 'ng2-archwizard';
import { NgbModal, NgbTimepicker} from '@ng-bootstrap/ng-bootstrap';
declare var $: any;


@Component({
  selector: 'app-add-vehicle',
  templateUrl: './add-vehicle.component.html',
  styleUrls: ['./add-vehicle.component.scss'],
  animations: [routerTransition()]
})
export class AddVehicleComponent implements OnInit {
  vehicleData = "";
  @ViewChild(WizardComponent)
  public wizard: WizardComponent;
  // this is for first step
  vehicleForm1: FormGroup;
  form1submit = false;
  form1Valid = true;
  // this is for second step
  vehicleForm2: FormGroup;
  form2submit = false;
  form2Valid = true;
  attchRc:string;
  attchPermit:string;
  attchTax:string;
  attchPuc:string;
  attchFitness:string;
  attchInsurance:string;

  maxPickerDate = {
     year: new Date().getFullYear(),
     month: new Date().getMonth() + 1,
     day: new Date().getDate()
};

minPickerDate = {
   year: new Date().getFullYear() - 30,
   month: 1,
   day: 1
};


 constructor(
    public router: Router,
    private fb: FormBuilder,
    private toaster: ToastrService,
    private userService : UserService
  ) {}

      /*
        Developer: Ravi
        Date: 08-aug-2019
        title: getter function
        Use: This function is use for getting form controls
    */

   get f1() {
    console.log(this.vehicleForm1.controls);
    return this.vehicleForm1.controls;
  }
  get f2() {
    return this.vehicleForm2.controls;
  }

 /*
        Developer: Ravi
        Date: 08-Aug-2019 createForm() {
    this.vehicleForm1 = this.fb.group({
      'registrationNumber': ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'chassisNumber': ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'engineNumber' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'vehicleClass' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'manufacturerMaker' :['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'loadCapacity' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'typeNumber' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'model' : ['',[ Validators.required]],
      'regitrationDate' : ['',[ Validators.required]],
      'fuleType' : ['',[ Validators.required]],
      'platformType' : ['',[ Validators.required]],
      'permitType' : ['',[ Validators.required]],
      'permitStartDate' : ['',[ Validators.required]],
      'permitUpto' : ['',[ Validators.required]],
      'insuranceStartDate' : ['',[ Validators.required]],
      'insuranceUpto' : ['',[ Validators.required]],
      'fitnessStartDate' : ['',[ Validators.required]],
      'fitnessUpto' : ['',[ Validators.required]],
      'pucStartDate' : ['',[ Validators.required]],
      'pucUpto' : ['',[ Validators.required]],
      'commercialTextPaidUpto' : ['',[ Validators.required]],
      'commercialTextPaidDate' : ['',[ Validators.required]],
      'tyreCompany' : ['',[ Validators.required]],
      'tyreChangeDate' : ['',[ Validators.required]],
      'odemeterReading' : ['',[ Validators.required]],
      'onBoardingDate' : ['',[ Validators.required]],
      'time' : ['',[ Validators.required]],
    });
    this.vehicleForm2 = this.fb.group({
      'ownerType' : ['',[ Validators.required]],
      'contactNumber' :['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.mobileMin), Validators.maxLength(validate.addVehicleRules.mobileMax)]],
      'addressLine1' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.addressMin), Validators.maxLength(validate.addVehicleRules.addressMax)]],
      'addressLine2' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.addressMin), Validators.maxLength(validate.addVehicleRules.addressMax)]],
      'ownerName' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.firtsNameMin), Validators.maxLength(validate.addVehicleRules.firtsNameMin)]],
      'state' : ['',[ Validators.required]],
      'city' : ['',[ Validators.required]],
      'pineCode' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.pinCodeMin), Validators.maxLength(validate.addVehicleRules.pinCodeMax)]]
  });
}
        title: initialize the app function
        Use: This function is use initialize the app
    */

   ngOnInit() {
    this.createForm()
  }

   /*
        Developer: Ravi
        Date: 08-aug-2019
        title: open modal
        Use: This function is use for open success modal
    */

   showModal(){
    $("#successModal").modal('show');
}

/*
    Developer: Ravi
    Date: 08-aug-2019
    title: close modal
    Use: This function is use for close success modal
*/

closeModal(){
    $("#successModal").modal('hide');
    this.router.navigate(['/vehicle-management']);
}

numberOnly(event): boolean {
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;

}


   /*
        Developer: Ravi
        Date: 08-aug-2019
        title: Validate the form field
        Use: This function is use for validate the function
    */

   createForm() {
    let numberRegex = /^[0-9]+$/; //This regex used for validate only numeric value
    let charecterRegex = /^[a-zA-Z]+$/; //This regex used for validate only numeric value
    let numCharRegex = /^[a-zA-Z0-9]+$/;
    this.vehicleForm1 = this.fb.group({
      'registrationNumber': ['',[ Validators.required, Validators.pattern(numCharRegex), Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'chassisNumber': ['',[ Validators.required, Validators.pattern(numCharRegex), Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'engineNumber' : ['',[ Validators.required,  Validators.pattern(numCharRegex), Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'vehicleClass' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'manufacturerMaker' :['',[ Validators.required, Validators.pattern(charecterRegex),  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'loadCapacity' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'typeNumber' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.regNumberMin), Validators.maxLength(validate.addVehicleRules.regNumberMax)]],
      'model' : ['',[ Validators.required]],
      'regitrationDate' : ['',[ Validators.required]],
      'fuleType' : ['',[ Validators.required]],
      'platformType' : ['',[ Validators.required]],
      'permitType' : ['',[ Validators.required]],
      'permitStartDate' : ['',[ Validators.required]],
      'permitUpto' : ['',[ Validators.required]],
      'insuranceStartDate' : ['',[ Validators.required]],
      'insuranceUpto' : ['',[ Validators.required]],
      'fitnessStartDate' : ['',[ Validators.required]],
      'fitnessUpto' : ['',[ Validators.required]],
      'pucStartDate' : ['',[ Validators.required]],
      'pucUpto' : ['',[ Validators.required]],
      'commercialTextPaidUpto' : ['',[ Validators.required]],
      'commercialTextPaidDate' : ['',[ Validators.required]],
      'tyreCompany' : ['',[ Validators.required]],
      'tyreChangeDate' : ['',[ Validators.required]],
      'odemeterReading' : ['',[ Validators.required]],
      'onBoardingDate' : ['',[ Validators.required]],
      'time' : ['',[ Validators.required]],
    });
    this.vehicleForm2 = this.fb.group({
      'ownerType' : ['',[ Validators.required]],
      'contactNumber' :['',[ Validators.required, Validators.pattern(numberRegex),  Validators.minLength(validate.addVehicleRules.mobileMin), Validators.maxLength(validate.addVehicleRules.mobileMax)]],
      'addressLine1' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.addressMin), Validators.maxLength(validate.addVehicleRules.addressMax)]],
      'addressLine2' : ['',[ Validators.required,  Validators.minLength(validate.addVehicleRules.addressMin), Validators.maxLength(validate.addVehicleRules.addressMax)]],
      'ownerName' : ['',[ Validators.required, Validators.pattern(charecterRegex),  Validators.minLength(validate.addVehicleRules.firtsNameMin), Validators.maxLength(validate.addVehicleRules.firtsNameMin)]],
      'state' : ['',[ Validators.required]],
      'city' : ['',[ Validators.required]],
      'pineCode' : ['',[ Validators.required,  Validators.pattern(numberRegex), Validators.minLength(validate.addVehicleRules.pinCodeMin), Validators.maxLength(validate.addVehicleRules.pinCodeMax)]]
  });
}

onFileChange(event) {
  var Target = event.target;
  var idAttr = Target.attributes.id;
  var value = idAttr.nodeValue;
    if(value == "attchRc"){
      this.attchRc = event.target.files[0].name;
    }
    if(value == "attchPermit"){
      this.attchPermit = event.target.files[0].name;
    }
    if(value == "attchTax"){
      this.attchTax = event.target.files[0].name;
    }
    if(value == "attchPuc"){
      this.attchPuc = event.target.files[0].name;
    }
    if(value == "attchFitness"){
      this.attchFitness = event.target.files[0].name;
    }
    if(value == "attchInsurance"){
      this.attchInsurance = event.target.files[0].name;
    }


}

/*
    Developer: Ravi
    Date: 08-aug-2019
    title: submit the form
    Use: This function is use for submit the form and sumbit the validate data
*/

   // this is for first step submit validation
   onSubmit1(){
     //console.log(this.vehicleForm1.value)
    this.form1submit = true;
    if (this.vehicleForm1.invalid) {
        return;
    }else{
      this.wizard.navigation.goToStep(1);
      this.form1Valid = true;
      let form1Data ={
      registrationNumber: this.vehicleForm1.value.registrationNumber ,
      chassisNumber: this.vehicleForm1.value.chassisNumber,
      engineNumber :this.vehicleForm1.value.engineNumber,
      vehicleClass : this.vehicleForm1.value.vehicleClass,
      manufacturerMaker :this.vehicleForm1.value.manufacturerMaker,
      loadCapacity :this.vehicleForm1.value.loadCapacity,
      typeNumber : this.vehicleForm1.value.typeNumber,
      model :this.vehicleForm1.value.model,
      regitrationDate : this.vehicleForm1.value.regitrationDate,
      fuleType : this.vehicleForm1.value.fuleType,
      platformType : this.vehicleForm1.value.platformType,
      permitType : this.vehicleForm1.value.permitType,
      permitStartDate : this.vehicleForm1.value.permitStartDate,
      permitUpto : this.vehicleForm1.value.permitUpto,
      insuranceStartDate : this.vehicleForm1.value.insuranceStartDate,
      insuranceUpto : this.vehicleForm1.value.insuranceUpto,
      fitnessStartDate : this.vehicleForm1.value.fitnessStartDate,
      fitnessUpto :this.vehicleForm1.value.fitnessUpto,
      pucStartDate : this.vehicleForm1.value.pucStartDate,
      pucUpto : this.vehicleForm1.value.pucUpto,
      commercialTextPaidUpto : this.vehicleForm1.value.commercialTextPaidUpto,
      commercialTextPaidDate : this.vehicleForm1.value.commercialTextPaidDate,
      tyreCompany : this.vehicleForm1.value.tyreCompany,
      tyreChangeDate : this.vehicleForm1.value.tyreChangeDate,
      odemeterReading : this.vehicleForm1.value.odemeterReading,
      onBoardingDate : this.vehicleForm1.value.onBoardingDate,
      time :this.vehicleForm1.value.time,
      }
     // this.vehicleData = form1Data;
      console.log(form1Data)
    }
  }
  // this is for first step2 submit validation
  onSubmit2(){
    this.form2submit = true;
    if (this.vehicleForm2.invalid) {
        return;
    }else{
      let form2data = {
      ownerType : this.vehicleForm2.value.ownerType,
      contactNumber :this.vehicleForm2.value.contactNumber,
      addressLine1 : this.vehicleForm2.value.addressLine1,
      addressLine2 : this.vehicleForm2.value.addressLine2,
      ownerName : this.vehicleForm2.value.ownerName,
      state : this.vehicleForm2.value.state,
      city :this.vehicleForm2.value.city,
      pineCode : this.vehicleForm2.value.pineCode
      }
      console.log(form2data)
      this.showModal();
      const userObj = {
        vehicleNo: "9712304978",
        vehicleType: "123456",
        rc: "9712304978",
        puc: "123456",
        insurance: "9712304978"
    };

    this.userService.addVehicle(userObj).subscribe((data: any) => {
        // console.log(data);
        if (data.success === true) {
            // this.authService.storeUserData(data.token, data.user);
            // this.router.navigate(['/dashboard']);
            // this.toaster.success(data.message);
        } else {
            this.toaster.error(data.message);
        }
    });

      this.wizard.navigation(['/vehicle-management']);
    }
  }
}
