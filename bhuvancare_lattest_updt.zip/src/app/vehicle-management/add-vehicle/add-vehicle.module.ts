import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddVehicleComponent } from './add-vehicle.component';
import { AddVehicleRoutingModule } from './add-vehicle-routing.module';
import { LayoutModule } from '../../layout/layout.module';
import { SidebarModule } from '../../layout/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { ArchwizardModule } from 'ng2-archwizard';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [AddVehicleComponent],
  imports: [
    CommonModule,
    AddVehicleRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule,
    ArchwizardModule,
    NgbModule
  ]
})
export class AddVehicleModule { }
