import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VehicleManagementComponent } from './vehicle-management.component';
import { VehicleManagementRoutingModule } from './vehicle-management-routing.module';
import { LayoutModule } from '../layout/layout.module';
import { SidebarModule } from '../layout/sidebar/sidebar.module';
import { ListViewModule } from '../layout/list-view/list-view.module';
import { AddVehicleModule } from './add-vehicle/add-vehicle.module';

import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [VehicleManagementComponent],
  imports: [
    CommonModule,
    VehicleManagementRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule,
    AddVehicleModule,
    ListViewModule
  ]
})
export class VehicleManagementModule { }
