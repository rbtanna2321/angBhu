import { Component, OnInit,ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {MovingDirection, WizardComponent} from 'ng2-archwizard';

import * as env from '../globals/env';
import * as validate from '../globals/validate';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, NgbTimepicker} from '@ng-bootstrap/ng-bootstrap';
declare var $: any;


@Component({
  selector: 'app-driver-management',
  templateUrl: './driver-management.component.html',
  styleUrls: ['./driver-management.component.scss']
})
export class DriverManagementComponent implements OnInit {
  @ViewChild(WizardComponent)
  public wizard: WizardComponent;
  // this is for first step
  driverForm1: FormGroup;
  form1submit = false;
  form1Valid = true;
  // this is for second step
  driverForm2: FormGroup;
  form2submit = false;
  form2Valid = true;
   // this is for fourth step
   driverForm3: FormGroup;
   form3submit = false;
   form3Valid = true;

   // this is for five step
   driverForm4: FormGroup;
   form4submit = false;
   form4Valid = true;
   // this is for six step
   driverForm5: FormGroup;
   form5submit = false;
   form5Valid = true;

   // this is for seven step
   driverForm6: FormGroup;
   form6submit = false;
   form6Valid = true;
  constructor(
    public router: Router,
    private fb: FormBuilder,
  ) {}

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: getter function
        Use: This function is use for getting form controls
    */

    get f1() {
      return this.driverForm1.controls;
    }
    get f2() {
      console.log(this.driverForm2.controls);
      return this.driverForm2.controls;
    }
    get f3() {
      return this.driverForm3.controls;
    }
    get f4() {
      return this.driverForm4.controls;
    }
    get f5() {
      return this.driverForm5.controls;
    }

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: initialize the app function
        Use: This function is use initialize the app
    */

    ngOnInit() {
      this.createForm()
    }

     /*
        Developer: Ravi
        Date: 10-aug-2019
        title: open modal
        Use: This function is use for open success modal,
        params : "",
        response : ""
    */

   showModal(){
    $("#driverSubmit").modal('show');
}

/*
    Developer: Ravi
    Date: 10-aug-2019
    title: close modal
    Use: This function is use for close success modal,
    params : "",
    response : ""
*/

closeModal(){
    $("#driverSubmit").modal('hide');
    this.router.navigate(['/dashboard']);
}

    createForm() {
      let numberRegex = /^[0-9]+$/; //This regex used for validate only numeric value
      let charecterRegex = /^[a-zA-Z]+$/; //This regex used for validate only numeric value
      let charDotRegex = /^[a-zA-Z]+$/; //This regex used for validate only numeric value
      let numCharRegex = /^[a-zA-Z0-9]+$/;
        this.driverForm1 = this.fb.group({
            'title': ['', [ Validators.required, Validators.pattern(charDotRegex), Validators.minLength(validate.addDriverRules.titleMin), Validators.maxLength(validate.addDriverRules.titleMax)] ],
            'firstName' : ['',[ Validators.required, Validators.pattern(charecterRegex), Validators.minLength(validate.addDriverRules.firtsNameMin), Validators.maxLength(validate.addDriverRules.firtsNameMax)]],
            'lastName' : ['',[ Validators.required, Validators.pattern(charecterRegex), Validators.minLength(validate.addDriverRules.lastNameMin), Validators.maxLength(validate.addDriverRules.lastNameMax)]],
            'caste' : ['',[ Validators.required]],
            'religion' : ['',[ Validators.required]],
            'dateOfBirth' : ['',[ Validators.required]],
            'secondMobileNo' : ['',[ Validators.required, Validators.pattern(numberRegex),Validators.minLength(validate.addDriverRules.mobileMin), Validators.maxLength(validate.addDriverRules.mobileMax)]],
            'emailId' : ['',[ Validators.required,Validators.email]],
            'mobileNo' : ['',[ Validators.required, Validators.pattern(numberRegex), Validators.minLength(validate.addDriverRules.mobileMin), Validators.maxLength(validate.addDriverRules.mobileMax)]],
            'bloodGroup' : ['',[ Validators.required]],
            'maritialStatus': ['',[ Validators.required]],
            'gender': ['',[ Validators.required]]
        });
        this.driverForm2 = this.fb.group({
          'address1': ['', [ Validators.required ,  Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)] ],
          'address2' : ['',[ Validators.required, Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)]],
          'state' : ['',[ Validators.required]],
          'city' : ['',[ Validators.required]],
          'pinCode' : ['',[ Validators.required, Validators.pattern(numberRegex),  Validators.minLength(validate.addDriverRules.pinCodeMin), Validators.maxLength(validate.addDriverRules.pinCodeMax)]],
          'oAddress1' : ['', [ Validators.required ,  Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)] ],
          'oAddress2' : ['', [ Validators.required ,  Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)] ],
          'oState' : ['',[ Validators.required]],
          'oCity' : ['',[ Validators.required]],
          'oPinCode' : ['',[ Validators.required, Validators.pattern(numberRegex),  Validators.minLength(validate.addDriverRules.pinCodeMin), Validators.maxLength(validate.addDriverRules.pinCodeMax)]],
          'pAddress1': ['', [ Validators.required ,  Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)] ],
          'pAddress2': ['', [ Validators.required ,  Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)] ],
          'pState' : ['',[ Validators.required]],
          'pCity' : ['',[ Validators.required]],
          'pPinCode' : ['',[ Validators.required, Validators.pattern(numberRegex),  Validators.minLength(validate.addDriverRules.pinCodeMin), Validators.maxLength(validate.addDriverRules.pinCodeMax)]]
      });
      this.driverForm3 = this.fb.group({
        'bankName': ['',[ Validators.required, Validators.pattern(charecterRegex),  Validators.minLength(validate.addDriverRules.bankNameMin), Validators.maxLength(validate.addDriverRules.bankNameMax)]],
        'acNumber' : ['',[ Validators.required, Validators.pattern(numberRegex),  Validators.minLength(validate.addDriverRules.accNumberMin), Validators.maxLength(validate.addDriverRules.accNumberMax)]],
        'ifscCode' : ['',[ Validators.required, Validators.pattern(numCharRegex),  Validators.minLength(validate.addDriverRules.ifscCodeMin), Validators.maxLength(validate.addDriverRules.ifscCodeMax)]]
    });
    this.driverForm4 = this.fb.group({
      'contactNo': ['',[ Validators.required, Validators.pattern(numberRegex), Validators.minLength(validate.addDriverRules.mobileMin), Validators.maxLength(validate.addDriverRules.mobileMax)]],
      'personName' : ['',[ Validators.required,  Validators.pattern(charecterRegex),  Validators.minLength(validate.addDriverRules.firtsNameMin), Validators.maxLength(validate.addDriverRules.firtsNameMax)]],
      'relation' : ['',[ Validators.required,  Validators.pattern(charecterRegex), Validators.minLength(validate.addDriverRules.relationMin), Validators.maxLength(validate.addDriverRules.relationMax)]],
      'conPerson': ['',[ Validators.required,  Validators.pattern(charecterRegex), Validators.minLength(validate.addDriverRules.firtsNameMin), Validators.maxLength(validate.addDriverRules.firtsNameMax)]],
      'relations' : ['',[ Validators.required,  Validators.pattern(charecterRegex), Validators.minLength(validate.addDriverRules.relationMin), Validators.maxLength(validate.addDriverRules.relationMax)]],
      'contactNumber' : ['',[ Validators.required, Validators.pattern(numberRegex), Validators.minLength(validate.addDriverRules.mobileMin), Validators.maxLength(validate.addDriverRules.mobileMax)]]
  });
  this.driverForm5 = this.fb.group({
    'nomineeName': ['',[ Validators.required,  Validators.pattern(charecterRegex), Validators.minLength(validate.addDriverRules.firtsNameMin), Validators.maxLength(validate.addDriverRules.firtsNameMax)]],
    'nomineeRelation' : ['',[ Validators.required,  Validators.pattern(charecterRegex), Validators.minLength(validate.addDriverRules.relationMin), Validators.maxLength(validate.addDriverRules.relationMax)]],
    'contactNo' : ['',[ Validators.required,   Validators.pattern(numCharRegex), Validators.minLength(validate.addDriverRules.mobileMin), Validators.maxLength(validate.addDriverRules.mobileMax)]],
    'nomineeDob': ['', [ Validators.required] ],
    'address1' : ['', [ Validators.required ,  Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)] ],
    'address2' : ['', [ Validators.required ,  Validators.minLength(validate.addDriverRules.addressMin), Validators.maxLength(validate.addDriverRules.addressMax)] ],
    'state' : ['',[ Validators.required]],
    'city' : ['',[ Validators.required]],
    'pinCode' : ['',[ Validators.required,   Validators.pattern(numCharRegex),  Validators.minLength(validate.addDriverRules.pinCodeMin), Validators.maxLength(validate.addDriverRules.pinCodeMax)]]
});
    }
    // this is for step submit validation
    onSubmit1(){
      this.form1submit = true;
      if (this.driverForm1.invalid) {
          return;
      }else{
        this.wizard.navigation.goToStep(1);
        this.form1Valid = true;
      }
    }

    // this is for step2 submit validation
    onSubmit2(){
      this.form2submit = true;
      if (this.driverForm2.invalid) {
          return;
      }else{
        this.wizard.navigation.goToStep(2);
        this.form2Valid = true;

      }
    }

     // this is for step3 submit validation
     onSubmit3(){
      this.form3submit = true;
      if (this.driverForm3.invalid) {
          return;
      }else{
        this.wizard.navigation.goToStep(4);
        this.form3Valid = true;

      }
    }

     // this is for step4 submit validation
     onSubmit4(){
      this.form4submit = true;
      if (this.driverForm4.invalid) {
          return;
      }else{
        this.wizard.navigation.goToStep(5);
        this.form4Valid = true;

      }
    }

     // this is for step5 submit validation
    onSubmit5(){
      this.form5submit = true;
      if (this.driverForm5.invalid) {
          return;
      }else{
        this.wizard.navigation.goToStep(6);
        this.form5Valid = true;
      }
    }

    // this is for step6 submit validation
    onSubmit6(){
      this.showModal();
      this.form6submit = true;
      if (this.driverForm6.invalid) {
          return;
      }else{
        const driverObj = {
            mobileNumber: "9712304978",
            password: "123456",
        };


        /*this.driverService.addDriver(driverObj).subscribe((data: any) => {
            console.log(data);
            if (data.success === true) {
                // this.authService.storeUserData(data.token, data.user);
                // this.router.navigate(['/dashboard']);
                // this.toaster.success(data.message);
            } else {
                this.toaster.error(data.message);
            }
        });*/
        this.wizard.navigation(['/dashboard']);
      }
    }
}
