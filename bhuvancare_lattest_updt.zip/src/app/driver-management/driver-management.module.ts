import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DriverManagementComponent } from './driver-management.component';
import { DriverManagementRoutingModule } from './driver-management-routing.module';
import { LayoutModule } from '../layout/layout.module';
import { SidebarModule } from '../layout/sidebar/sidebar.module';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { ArchwizardModule } from 'ng2-archwizard';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [DriverManagementComponent],
  imports: [
    CommonModule,
    DriverManagementRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule,
    ArchwizardModule,
    NgbModule
  ]
})
export class DriverManagementModule { }
