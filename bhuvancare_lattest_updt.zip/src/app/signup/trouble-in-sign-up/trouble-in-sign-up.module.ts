import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TroubleInSignUpComponent } from './trouble-in-sign-up.component';
import { TroubleInSignUpRoutingModule } from './trouble-in-sign-up-routing.module';

@NgModule({
  declarations: [TroubleInSignUpComponent],
  imports: [
    CommonModule,
    TroubleInSignUpRoutingModule
  ]
})
export class TroubleInSignUpModule { }
