import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TroubleInSignUpComponent } from './trouble-in-sign-up.component';

describe('TroubleInSignUpComponent', () => {
  let component: TroubleInSignUpComponent;
  let fixture: ComponentFixture<TroubleInSignUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TroubleInSignUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TroubleInSignUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
