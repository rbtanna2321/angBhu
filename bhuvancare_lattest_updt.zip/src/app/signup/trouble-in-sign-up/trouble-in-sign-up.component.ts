import { Component, OnInit } from '@angular/core';
import * as env from '../../globals/env';

@Component({
  selector: 'app-trouble-in-sign-up',
  templateUrl: './trouble-in-sign-up.component.html',
  styleUrls: ['./trouble-in-sign-up.component.scss']
})
export class TroubleInSignUpComponent implements OnInit {
  logo = env.LOGO_PATH;

  constructor() { }

  ngOnInit() {
  }

}
