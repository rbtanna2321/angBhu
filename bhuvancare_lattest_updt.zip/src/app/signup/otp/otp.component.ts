import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../../router.animations';
import { AuthenticationService } from '../../services/authentication.service';
import { UserService } from '../../services/user.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { interval } from 'rxjs/observable/interval';
import { Observable, timer } from 'rxjs';
import { take, map } from 'rxjs/operators';
import * as env from '../../globals/env';
import { async } from 'q';

declare var $: any;

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.scss'],
  animations: [routerTransition()]
})
export class OtpComponent implements OnInit {
  otpForm : FormGroup;
  submitted = false;
  counter$: Observable<number>;
  count = env.OTP_SECONDS;
  logo = env.LOGO_PATH;

  error ="";
  constructor(
    public router: Router,
    public authService: AuthenticationService,
    private toaster: ToastrService,
    private fb: FormBuilder,
    private userService : UserService
  ) {
      this.counter$ = timer(0,1000).pipe(
       take(this.count),
       map(() => --this.count)
     );
  }

  keytab(event){
    let nextInput = event.srcElement.nextElementSibling; // get the sibling element

    var target = event.target || event.srcElement;
    var id = target.id
    if(nextInput == null)  // check the maxLength from here
        return;
    else
        nextInput.focus();   // focus if not null
}

  ngOnInit() {
    this.createForm();
  }


  get f() {
    return this.otpForm.controls;
  }


  createForm() {
    let numericRegex = /^[0-9]+$/; //This regex used for validate only numeric value
      this.otpForm = this.fb.group({
        'otpDigit1': ['', [Validators.required, Validators.pattern(numericRegex) ] ],
        'otpDigit2': ['', [Validators.required, Validators.pattern(numericRegex) ] ],
        'otpDigit3': ['', [Validators.required, Validators.pattern(numericRegex) ] ],
        'otpDigit4': ['', [Validators.required, Validators.pattern(numericRegex) ] ],
        'otpDigit5': ['', [Validators.required , Validators.pattern(numericRegex)] ],
        'otpDigit6': ['', [Validators.required , Validators.pattern(numericRegex) ] ]
      });
  }

  /*
      Developer: Ravi
      Date: 01-aug-2019
      title: open modal
      Use: This function is use for open success modal
  */

  showModal(){
      $("#verifyEmail").modal('show');
  }

  /*
      Developer: Ravi
      Date: 01-aug-2019
      title: close modal
      Use: This function is use for close success modal
  */

  closeModal(){
      $("#verifyEmail").modal('hide');
      this.router.navigate(['/login']);
  }



  onSubmit() {
    this.submitted = true;
    if (this.otpForm.invalid) {
        return;

    }else{
      let otp = this.otpForm.value.otpDigit1 + this.otpForm.value.otpDigit2 + this.otpForm.value.otpDigit3 + this.otpForm.value.otpDigit4 + this.otpForm.value.otpDigit5 +this.otpForm.value.otpDigit6;
      const userObj ={
        url : "https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare/api/v1/ent/verifyotp",
       params : {
        otp: otp,
        email: "ram@mailinator.com"
       }
     };
     this.userService.otpVerify(userObj).subscribe((data: any) => {
      if (data.status === "SUCCESS") {
          //this.authService.storeUserData(data.token, data.user);
          this.router.navigate(['/login']);
         // this.toaster.success(data.message);
      } else {
        this.error = data.error.message;
        $("#verifyEmail").modal('show');
        //this.toaster.error(data.error);
      }
  });
        this.showModal();
    }
  }

}
