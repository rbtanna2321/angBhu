import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup.component';
import { PasswordComponent } from './password/password.component';

const routes: Routes = [
    {
        path: '', component: SignupComponent
    },
    {
        path: 'password', component: PasswordComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SignupRoutingModule {
}
