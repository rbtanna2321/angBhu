import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { routerTransition } from '../router.animations';
import { UserService } from '../services/user.service';
import { ToastrService } from 'ngx-toastr';

import * as env from '../globals/env';
import * as validate from '../globals/validate';
declare var $: any;


@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.scss'],
    animations: [routerTransition()]
})

export class SignupComponent implements OnInit {
     signupForm: FormGroup;
     submitted = false;
     logo = env.LOGO_PATH
    error = "";
    signupFormData = "";
    constructor(
      public router: Router,
      private fb: FormBuilder,
      private toaster: ToastrService,
      private userService : UserService
    ) {}

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: getter function
        Use: This function is use for getting form controls
    */

    get f() {
      return this.signupForm.controls;
    }

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: initialize the app function
        Use: This function is use initialize the app
    */

    ngOnInit() {
      this.createForm()
    }

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: Validate the form field
        Use: This function is use for validate the function
    */

    createForm() {
        let numericRegex = /^[0-9]+$/; //This regex used for validate only numeric value
        let gstValidation = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
        let email = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;

        this.signupForm = this.fb.group({
            'companyName': ['', [ Validators.required,Validators.maxLength(validate.signupRules.comapnyNameMax),Validators.minLength(3)] ],
            'gstNo': ['', [Validators.required,Validators.pattern(gstValidation) ] ],
            'natureOfBusiness' : ['', [ Validators.required,Validators.maxLength(validate.signupRules.comapnyNameMax),Validators.minLength(3)] ],
            'contactNo' : ['',[ Validators.required,Validators.pattern(numericRegex),Validators.maxLength(validate.signupRules.contactNoMax),Validators.minLength(validate.signupRules.contactNoMin)]],
            'emailId' : ['',[ Validators.required,Validators.pattern(email),Validators.maxLength(validate.signupRules.emailMax)]],
            'addressLine1' : ['',[Validators.required,Validators.maxLength(validate.signupRules.addressLine1Max),Validators.minLength(validate.signupRules.addressLine1Min)]],
            'state' : ['',[ Validators.required]],
            'city' : ['',[ Validators.required]],
            'pinCode' : ['',[ Validators.required,Validators.pattern(numericRegex),Validators.maxLength(validate.signupRules.pinCodeMax),Validators.minLength(validate.signupRules.pinCodeMin)]]
        });
    }

    /*
        Developer: Ravi
        Date: 01-aug-2019
        title: open modal
        Use: This function is use for open success modal
    */

    showModal(){
        $("#successModal").modal('show');
    }

    /*
        Developer: Ravi
        Date: 01-aug-2019
        title: close modal
        Use: This function is use for close success modal
    */

    closeModal(){
        $("#successModal").modal('hide');
        this.router.navigate(['/otp']);
    }

    /*
        Developer: Ravi
        Date: 25-jul-2019
        title: submit the form
        Use: This function is use for submit the form and sumbit the validate data
    */

    onSubmit() {
      this.submitted = true;
      console.log(this.signupForm);
      if (this.signupForm.invalid) {
          return;
      }else{
        this.signupFormData = this.signupForm.value;
        this.router.navigate(['sign-up/password']);
        const userObj ={
             url : "https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare/api/v1/ent/register",
            params : {
                companyName: this.signupForm.value.companyName,
                gstNo: this.signupForm.value.gstNo,
                natureOfBusiness: this.signupForm.value.natureOfBusiness,
                contactNo: this.signupForm.value.contactNo,
                email: this.signupForm.value.emailId,
                addressLine1: this.signupForm.value.addressLine1,
                addressLine2: this.signupForm.value.addressLine2,
                state: this.signupForm.value.state,
                city: this.signupForm.value.city,
                pinCode: this.signupForm.value.pinCode,
            }
          };
                // const userObj =  {
                //   name:"tesdfsdfst",
                //   salary:"123",
                //   age:"23"
                // };

                this.userService.signupEnterprise(userObj).subscribe((data: any) => {

                    if (data.status === "SUCCESS") {
                        //this.authService.storeUserData(data.token, data.user);
                        this.router.navigate(['/otp']);
                        this.toaster.success(data.message);
                    } else {
                      this.error = data.error.message;
                      $("#loginError").modal('show');
                      //this.toaster.error(data.error);
                    }
                });
      }
    }
}
