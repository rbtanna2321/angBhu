import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../../router.animations';
import { AuthenticationService } from '../../services/authentication.service';
import { UserService } from '../../services/user.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { Observable, timer } from 'rxjs';
import { take, map } from 'rxjs/operators';
import * as env from '../../globals/env';
declare var $: any;
@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.scss'],
  animations: [routerTransition()]
})
export class PasswordComponent implements OnInit {
  passwordForm : FormGroup;
  password ="";
  error="";
  logo = env.LOGO_PATH
  submitted = false;
  constructor(
    public router: Router,
    public authService: AuthenticationService,
    private toaster: ToastrService,
    private fb: FormBuilder,
    private userService : UserService
  ) { }

  // private customValidator(control) {         
  //   console.log(this.passwordForm.value.password)
  //   return {isEqual: control.value === this.passwordForm.value.password}
  // }

  ngOnInit() {
    this.createForm();
  }


  get f() {
    console.log(this.passwordForm.controls);
    return this.passwordForm.controls;
  }

  createForm() {
      this.passwordForm = this.fb.group({
        'password': ['',[Validators.required ]],
        'confirmPassword': ['',[Validators.required ]],
      });
  }

  /*
      Developer: Ravi
      Date: 01-aug-2019
      title: open modal
      Use: This function is use for open success modal
  */

  showModal(){
      $("#verifyEmail").modal('show');
  }

  /*
      Developer: Ravi
      Date: 01-aug-2019
      title: close modal
      Use: This function is use for close success modal
  */

  closeModal(){
      $("#verifyEmail").modal('hide');
      this.router.navigate(['/login']);
  }

  onSubmit() {
    this.submitted = true;
    if (this.passwordForm.invalid) {
        return;
        
    }else{
      console.log("after",this.passwordForm)
      this.router.navigate(['/otp']);
      let password = this.passwordForm.value.password;
      console.log(password)
  //     const userObj ={
  //       url : "https://7i80ww78k4.execute-api.us-east-1.amazonaws.com/bhuvancare/api/v1/ent/verifyotp",
  //      params : {
  //       password: password,
  //       email: "ram@mailinator.com"
  //      }
  //    };
  //    this.userService.otpVerify(userObj).subscribe((data: any) => {
  //     if (data.status === "SUCCESS") {
  //         //this.authService.storeUserData(data.token, data.user);
  //         this.router.navigate(['/login']);
  //        // this.toaster.success(data.message);
  //     } else {
  //       this.error = data.error.message;
  //       $("#verifyEmail").modal('show');
  //       //this.toaster.error(data.error);
  //     }
  // });
        // this.showModal();
    }
  }

}
