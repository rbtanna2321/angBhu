import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { YourClientComponent } from './your-client.component';
import { YourClientRoutingModule } from './your-client-routing.module';
import { LayoutModule } from '../layout/layout.module';
import { SidebarModule } from '../layout/sidebar/sidebar.module';
import { ListViewModule } from '../layout/list-view/list-view.module';

import { AddYourClientModule } from './add-your-client/add-your-client.module';
import { ViewYourClientModule } from './view-your-client/view-your-client.module';

import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [YourClientComponent],
  imports: [
    CommonModule,
    YourClientRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule,
    ListViewModule,
    AddYourClientModule,
    ViewYourClientModule
  ]
})
export class YourClientModule { }
