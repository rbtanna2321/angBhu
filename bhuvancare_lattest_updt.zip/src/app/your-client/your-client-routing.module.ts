import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { YourClientComponent } from './your-client.component';
import { AddYourClientComponent } from './add-your-client/add-your-client.component';
import { ViewYourClientComponent } from './view-your-client/view-your-client.component';


const routes: Routes = [
    {
        path: '',
        component: YourClientComponent
    },
    {
        path: 'add',
        component: AddYourClientComponent
    },
    {
        path: 'view',
        component: ViewYourClientComponent
    }
];


@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class YourClientRoutingModule { }
