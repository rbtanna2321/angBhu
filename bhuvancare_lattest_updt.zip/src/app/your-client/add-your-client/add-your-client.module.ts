import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddYourClientComponent } from './add-your-client.component';
import { AddYourClientRoutingModule } from './add-your-client-routing.module';
import { LayoutModule } from '../../layout/layout.module';
import { SidebarModule } from '../../layout/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [AddYourClientComponent],
  imports: [
    CommonModule,
    AddYourClientRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule
  ]
})
export class AddYourClientModule { }
