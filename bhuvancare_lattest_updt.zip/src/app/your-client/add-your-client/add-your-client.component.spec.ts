import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddYourClientComponent } from './add-your-client.component';

describe('AddYourClientComponent', () => {
  let component: AddYourClientComponent;
  let fixture: ComponentFixture<AddYourClientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddYourClientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddYourClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
