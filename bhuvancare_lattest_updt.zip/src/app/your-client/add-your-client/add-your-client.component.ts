import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-your-client',
  templateUrl: './add-your-client.component.html',
  styleUrls: ['./add-your-client.component.scss']
})
export class AddYourClientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
