import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourClientComponent } from './your-client.component';

describe('YourClientComponent', () => {
  let component: YourClientComponent;
  let fixture: ComponentFixture<YourClientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourClientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
