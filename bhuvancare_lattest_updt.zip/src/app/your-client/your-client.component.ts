import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-client',
  templateUrl: './your-client.component.html',
  styleUrls: ['./your-client.component.scss']
})
export class YourClientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
