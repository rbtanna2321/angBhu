import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-your-client',
  templateUrl: './view-your-client.component.html',
  styleUrls: ['./view-your-client.component.scss']
})
export class ViewYourClientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
