import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewYourClientComponent } from './view-your-client.component';

describe('ViewYourClientComponent', () => {
  let component: ViewYourClientComponent;
  let fixture: ComponentFixture<ViewYourClientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewYourClientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewYourClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
