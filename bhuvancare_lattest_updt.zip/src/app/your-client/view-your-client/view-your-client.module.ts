import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewYourClientRoutingModule } from './view-your-client-routing.module';
import { ViewYourClientComponent } from './view-your-client.component';
import { LayoutModule } from '../../layout/layout.module';
import { SidebarModule } from '../../layout/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [ViewYourClientComponent],
  imports: [
    CommonModule,
    ViewYourClientRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule
  ]
})
export class ViewYourClientModule { }
