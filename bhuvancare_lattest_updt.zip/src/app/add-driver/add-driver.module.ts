import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddDriverComponent } from './add-driver.component';
import { AddDriverRoutingModule } from './add-driver-routing.module';

@NgModule({
  declarations: [AddDriverComponent],
  imports: [
    CommonModule,
    AddDriverRoutingModule
  ]
})
export class AddDriverModule { }
