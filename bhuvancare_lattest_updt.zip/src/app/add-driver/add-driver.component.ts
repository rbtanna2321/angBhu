import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-driver',
  templateUrl: './add-driver.component.html',
  styleUrls: ['./add-driver.component.scss']
})
export class AddDriverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
