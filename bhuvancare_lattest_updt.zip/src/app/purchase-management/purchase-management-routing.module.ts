import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PurchaseManagementComponent } from './purchase-management.component';
import { AddPurchaseOrderComponent } from './add-purchase-order/add-purchase-order.component';
import { ViewPurchaseOrderComponent } from './view-purchase-order/view-purchase-order.component';

const routes: Routes = [
  {
      path: '',
      component: PurchaseManagementComponent
  },
  {
      path: 'add',
      component: AddPurchaseOrderComponent
  },
  {
      path: 'view',
      component: ViewPurchaseOrderComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PurchaseManagementRoutingModule { }
