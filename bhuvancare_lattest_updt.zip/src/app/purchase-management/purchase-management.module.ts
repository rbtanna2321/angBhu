import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PurchaseManagementComponent } from './purchase-management.component';
import { PurchaseManagementRoutingModule } from './purchase-management-routing.module';
import { LayoutModule } from '../layout/layout.module';
import { SidebarModule } from '../layout/sidebar/sidebar.module';
import { AddPurchaseOrderModule } from './add-purchase-order/add-purchase-order.module';
import { ListViewModule } from '../layout/list-view/list-view.module';
import { ArchwizardModule } from 'ng2-archwizard';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { ViewPurchaseOrderComponent } from './view-purchase-order/view-purchase-order.component';

@NgModule({
  declarations: [PurchaseManagementComponent, ViewPurchaseOrderComponent],
  imports: [
    CommonModule,
    PurchaseManagementRoutingModule,
    LayoutModule,
    SidebarModule,
    TranslateModule,
    FormsModule,
    AddPurchaseOrderModule,
    ListViewModule,
    ReactiveFormsModule,
    NgbModule,
    ArchwizardModule

  ]
})
export class PurchaseManagementModule { }
