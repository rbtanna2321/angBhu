import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-management',
  templateUrl: './purchase-management.component.html',
  styleUrls: ['./purchase-management.component.scss']
})
export class PurchaseManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
