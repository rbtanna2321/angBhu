import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewPurchaseOrderComponent } from './view-purchase-order.component';
import { ViewPurchaseOrderRoutingModule } from './view-purchase-order-routing.module';
import { LayoutModule } from '../../layout/layout.module';
import { SidebarModule } from '../../layout/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [ViewPurchaseOrderComponent],
  imports: [
    CommonModule,
    ViewPurchaseOrderRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    SidebarModule
  ]
})
export class PurchaseOrderViewModule { }
