import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { routerTransition } from '../../router.animations';
import { UserService } from '../../services/user.service';
import * as env from '../../globals/env';
import * as validate from '../../globals/validate';
declare var $: any;
@Component({
  selector: 'app-view-purchase-order',
  templateUrl: './view-purchase-order.component.html',
  animations: [routerTransition()]
})
export class ViewPurchaseOrderComponent implements OnInit {

  purchaseOrderForm: FormGroup;
  submitted = false;
  constructor(
    public router: Router,
      private fb: FormBuilder,
      private toaster: ToastrService,
      private userService : UserService
  ) { }

  ngOnInit() {
  }

}
